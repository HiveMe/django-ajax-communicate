from django.db import models

# Create your models here.

class Data(models.Model):
	cycle = models.CharField(max_length=120)
	time = models.CharField(max_length=120)
	status = models.CharField(max_length=120)

