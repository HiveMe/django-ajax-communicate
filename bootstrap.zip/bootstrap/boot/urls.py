from django.conf.urls import url 
from .import views

urlpatterns = [
	url(r'^index/',views.index,name='index'),
	url(r'^data_delete/$',views.data_delete,name='data_delete')
]