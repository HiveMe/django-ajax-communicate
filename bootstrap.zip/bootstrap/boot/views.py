from django.shortcuts import render,get_object_or_404
from .models import Data
from django.views.generic import ListView

from django.http import JsonResponse
from django.views.decorators.http import require_POST
# Create your views here.
from django.views.decorators.csrf import csrf_exempt


def index(request):
	qs = Data.objects.all()
	return render(request,'boot.html',{"qs":qs})

@csrf_exempt
def data_delete(request):
	print('handling...')
	data_id = request.POST.get('id')
	action = request.POST.get('action')
	print(data_id)
	print(action)
	if data_id and action:
		print('ok  request')
		try:
			print('get')
			
			
			if action == 'delete' and data_id != 0:
				data = Data.objects.get(id=data_id)
				data.delete()
				print('delete')
				return JsonResponse({'status':'ok'})
			elif action == 'add':
				cycle = request.POST.get('cycle')
				time = request.POST.get('time')
				status = request.POST.get('status')
				d=Data(cycle=cycle,time=time,status=status)  
				d.save()
				print('add')
				print(d.id)
				return JsonResponse({'status':'ok','id':d.id})
			else:
				print('wtf')
		except e:
			print(e)
			pass
	print('not ok....')
	return JsonResponse({'status':'ko'})	